#include "MMM.h"

// --- MOTOR CONTROLLER --- //
MotorController::MotorController(int dir1, int pwm1, int dir2, int pwm2) {
  //assign pins
  DIR1 = dir1; 
  PWM1 = pwm1;
  DIR2 = dir2;
  PWM2 = pwm2;
}
void MotorController::initialize() {
  pinMode(DIR1,OUTPUT);
  pinMode(PWM1,OUTPUT);
  pinMode(DIR2,OUTPUT);
  pinMode(PWM2,OUTPUT);
}
void MotorController::spinMotors(int speed1, int speed2) { 
  //clamp speed 1
  if(speed1 > 255) { speed1 = 255; }
  if(speed1 < -255) { speed1 = -255; }
  //control motor 1
  if(speed1 > 0) {
    digitalWrite(DIR1,HIGH);
    analogWrite(PWM1,speed1);
  } else {
    digitalWrite(DIR1,LOW);
    analogWrite(PWM1,-speed1);
  }
  //clamp speed 2
  if(speed2 > 255) { speed2 = 255; }
  if(speed2 < -255) { speed2 = -255; }
  //control motor 2
  if(speed2 > 0) {
    digitalWrite(DIR2,HIGH);
    analogWrite(PWM2,speed2);
  } else {
    digitalWrite(DIR2,LOW);
    analogWrite(PWM2,-speed2);
  }
}

// --- STEPPER MOTOR --- //
StepperMotor::StepperMotor(int stepPin, int dirPin, int limitPin, 
                           int max, bool invertDir) {
  //assign pins
  STEP = stepPin;
  DIR = dirPin;
  LIMIT = limitPin;
  //set maximum position
  maxPos = max;
  //set inversion
  invert = invertDir;
  //homed
  home();
  homed = false;
}
void StepperMotor::initialize() {
  pinMode(STEP,OUTPUT);
  pinMode(DIR,OUTPUT);
  pinMode(LIMIT,INPUT);
}
void StepperMotor::stepTo(int steps, float delay, bool ignoreHome) {
  //check calibration
  if(homed || ignoreHome) {
    //set goal position and clamp
    toPos = steps;
    //if(toPos < 0) { toPos = 0; } 
    if(toPos > maxPos) { toPos = maxPos; }
    //set stepping speed
    delayTime = delay;
  }
}
void StepperMotor::step(int steps, float delay, bool ignoreHome) {
  //check calibration
  if(homed || ignoreHome) {
    //set goal position and clamp
    toPos += steps;
    //set stepping speed
    delayTime = delay;
  }
}
void StepperMotor::home() {
  homed = false;
  delayTime = 0.015;
  toPos = -20000;
}
void StepperMotor::zero() {
  digitalWrite(STEP,LOW);
  stepHigh = false;
  delayTime = 0;
  endTime = 0;
  toPos = 0;
  pos = 0;  
}
void StepperMotor::update() {
  if(pos != toPos) {
    unsigned long t = millis();
    if(t > endTime) {
      //increment the time
      endTime = t + delayTime;
      //turn HIGH or LOW to step next
      if(stepHigh) {
        digitalWrite(STEP,LOW);
        stepHigh = false;
      } else {
        digitalWrite(STEP,HIGH);
        stepHigh = true;
        //go forward
        if(pos < toPos) { 
          if(invert) { digitalWrite(DIR,HIGH); } 
          else { digitalWrite(DIR,LOW); }
          pos += 1; 
        } 
        //go backward
        if(pos > toPos) { 
          if(invert) { digitalWrite(DIR,LOW); } 
          else { digitalWrite(DIR,HIGH); }
          pos -= 1; 
          //check limit switch
          if(digitalRead(LIMIT) == HIGH) { zero(); homed = true; }    
        }
        //if arrived to goal position, stop
        if(pos == toPos) { delayTime = 0.015; }
      }
    } 
  }
}
int StepperMotor::getPos() { return pos; }

// --- SERVO MOTOR --- //
ServoMotor::ServoMotor(int pin, bool invertDir) {
  PIN = pin;
  invert = invertDir;
  attached = false;
}
void ServoMotor::on() {
  SERVO.attach(PIN);
  attached = true;
  endTime = 0;
  pos = 90; 
}
void ServoMotor::off() {
  SERVO.detach();
  attached = false;
}
void ServoMotor::rotateTo(int angle, float delay, bool OnOff) {
  //if On/Off enabled, turn servo off if negative value
  if(OnOff) {
    if (angle < 0) { off(); }
    else if (!attached) { on(); }
  }
  //move only if attached
  if(attached) {
    //set goal position and clamp
    toPos = angle;
    if(toPos < 0) { toPos = 0; } 
    if(toPos > 180) { toPos = 180; }
    //set stepping speed
    delayTime = delay;
  }
}
void ServoMotor::rotate(int angle, float delay) {
  //move only if attached
  if(attached) {
    //set goal position and clamp
    toPos += angle;
    if(toPos < 0) { toPos = 0; } 
    if(toPos > 180) { toPos = 180; }
    //set stepping speed
    delayTime = delay;
  }
}
void ServoMotor::update() {
  //move only if attached
  if(attached) {
    if(pos != toPos) {
      unsigned long t = millis();
      if(t > endTime) {
        //increment the time
        endTime = t + delayTime;
        //get closer to goal position
        if(pos < toPos) { pos += 1; } 
        if(pos > toPos) { pos -= 1; }
        //write the servo position
        if(invert) { SERVO.write(180-pos); }
        else { SERVO.write(pos); }
        //if arrived to goal position, stop
        if(pos == toPos) { delayTime = 15; }
      } 
    }
  }
}
int ServoMotor::getPos() { return pos; }
bool ServoMotor::isAttached() { return attached; }

// --- RANGE FINDER --- //
RangeFinder::RangeFinder(int echoPin, int trigPin, int min, int max, 
                         int delay, int timeOut) {
  ECHO = echoPin;
  TRIG = trigPin;
  minRange = min;
  maxRange = max;
  delayTime = delay;
  timeOutMicros = timeOut;
}
void RangeFinder::initialize() {
  pinMode(TRIG,OUTPUT);
  pinMode(ECHO,INPUT);
  range = -1;
  endTime = 0;
}
void RangeFinder::update() {
  unsigned long t = millis();
  if(t > endTime) {
    //increment the time
    endTime = t + delayTime;
    //pulse ultrasound out
    digitalWrite(TRIG, LOW); delayMicroseconds(2); 
    digitalWrite(TRIG, HIGH); delayMicroseconds(8); 
    digitalWrite(TRIG, LOW);
    //Measure distance
    long duration = pulseIn(ECHO, HIGH, timeOutMicros);
    long distance = duration/58.2;
    if(minRange < distance && distance < maxRange){
      range = int(distance);
    } else {
      range = -1;
    }
  } 
}
int RangeFinder::getRange() { return range; }

// --- FANS --- //
Fans::Fans(int pin) { PIN = pin; }
void Fans::initialize() { pinMode(PIN,OUTPUT); }
void Fans::on() { digitalWrite(PIN, HIGH); }
void Fans::off() { digitalWrite(PIN, LOW); }






