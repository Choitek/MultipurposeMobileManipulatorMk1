#include <Arduino.h>
#include <Servo.h>

// --- MOTOR CONTROLLER --- //
class MotorController {
  public:
    MotorController(int dir1, int pwm1, int dir2, int pwm2);
    void spinMotors(int speed1, int speed2);
    void initialize();
    void update();
  private:
    int DIR1;
    int PWM1;
    int DIR2;
    int PWM2;
};

// --- STEPPER MOTOR --- //
class StepperMotor {
  public:
    StepperMotor(int stepPin, int dirPin, int limitPin, int max, bool invertDir = false);
    void stepTo(int steps, float delay = 0.015, bool ignoreHome = false);
    void step(int steps, float delay = 0.015, bool ignoreHome = false);
    void initialize();
    void home();
    int getPos();  
    void update();
  private:
    int STEP;
    int DIR;
    int LIMIT; 
    float delayTime;
    unsigned long endTime;    
    bool stepHigh;
    void zero();
    bool invert;
    bool homed;    
    int maxPos;
    int toPos;
    int pos;    
};

// --- SERVO MOTOR ---//
class ServoMotor {
  public:
    ServoMotor(int pin, bool invertDir = false);
    void rotateTo(int angle, float delay = 15.0, bool OnOff = false);
    void rotate(int angle, float delay = 15.0);
    void on(); void off(); 
    bool isAttached();
    void update();
    int getPos();
  private:
    Servo SERVO;
    int PIN;    
    unsigned long endTime;
    float delayTime;   
    bool attached;
    bool invert;
    int toPos;
    int pos;
};

// --- RANGE FINDER --- //
class RangeFinder {
  public:
    RangeFinder(int echoPin, int trigPin, int min = 0, int max = 150, 
                int delay = 100, int timeOut = 5000000);  
    void initialize();
    void update();
    int getRange();
  private:
    int ECHO;  
    int TRIG;
    long timeOutMicros;   
    unsigned long endTime;
    float delayTime;      
    int minRange;
    int maxRange;
    int range;
};

// --- FANS --- //
class Fans {
  public:
    Fans(int pin);
    void initialize();
    void on(); void off();
  private:
    int PIN;    
};
